package org.schabi.parakeetype.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import org.schabi.parakeetype.settings.preferences.AppPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.*
import kotlin.math.sqrt
import kotlinx.coroutines.isActive

private const val TAG = "AudioCaptureManager"

/** 16 kHz mono - matches Parakeet V3's expected input format. */
private const val SAMPLE_RATE = 16_000

/** 32 ms window at 16 kHz = 512 samples per chunk. Matches Silero VAD's required frame size. */
private const val CHUNK_SAMPLES = 512

/**
 * Check every 10th chunk (~320 ms) whether Android silences this recording because another
 * app (a phone call, a voice recorder) has the microphone.
 */
private const val SILENCED_CHECK_INTERVAL_CHUNKS = 10

// Capture source: MediaRecorder.AudioSource.DEFAULT — the vendor-recommended source.
// It arrives at a usable level with the platform's standard voice processing, so no
// application-side gain is applied.
//
// History: rawer sources (VOICE_RECOGNITION, UNPROCESSED) with application-side gain
// were tried in 2026-08 on the theory that the TDT decoder was level- or shape-
// sensitive. That theory was disproven: the nemo128 frontend normalises each window to
// a fixed level, so the decoder is level-invariant (the same waveform at 0.1x / 0.5x /
// 1.0x yields byte-identical features). The short-word ("thanks") reliability gap was
// a decode-loop bug in ParakeetEngine — the predictor state must freeze on blank and
// the initial target must be blank — now fixed. DEFAULT is good enough; per-mic
// calibration in settings remains an optional refinement.
//
// Exception - [rawMicCapture] preference: `AudioSource.UNPROCESSED` is available
// (via startCapture(rawSource = true)) to bypass the platform voice processing
// entirely. The default source's AEC cancels audio played from the device's own
// speaker out of the mic stream, which makes the speakerphone use case
// (e.g. transcribing a voicemail playing on speaker) transcribe as silence.
// The TDT decoder is level-invariant, so the rawer level of UNPROCESSED does
// not affect transcription quality.

/**
 * Manages a single [AudioRecord] session and emits captured audio as a cold
 * [Flow]<[AudioChunk]>. Runs entirely on [Dispatchers.IO].
 *
 * Typical usage:
 * ```kotlin
 * val job = scope.launch {
 *     manager.startCapture().collect { chunk -> } // forward to inference
 * }
 * job.cancel() // stops recording and releases AudioRecord
 * ```
 */
class AudioCaptureManager(private val context: Context) {

    /** Calibration-selected microphone, applied to each [AudioRecord] via setPreferredDevice. */
    private val prefs = AppPreferences(context.applicationContext)

    /**
     * Set to `true` by [stopCapture] to end the read loop on the next iteration.
     * Using a flag instead of coroutine cancellation lets the [Flow] complete normally
     * so that the inference layer can emit a final result before tearing down.
     */
    @Volatile
    private var stopRequested: Boolean = false

    /**
     * Signals the active [startCapture] flow to exit its read loop and complete normally.
     * The flow will finish within one 40 ms chunk read cycle (~40 ms latency).
     */
    fun stopCapture() {
        stopRequested = true
    }

    /**
     * Starts microphone capture and emits each 40 ms [AudioChunk] downstream.
     *
     * **Prerequisites:** [PermissionHelper.hasRecordPermission] must return `true` before
     * calling this. If the permission is absent a [SecurityException] is thrown immediately
     * so the caller can transition the UI to an error state.
     *
     * The flow is cold - a new [AudioRecord] is created per collection. The [AudioRecord]
     * is always released in the `finally` block, even if the collector cancels mid-stream.
     *
     * The [AudioRecord] is built on [context], so a recognition-service session that passes an
     * attribution context (see [android.content.ContextParams.Builder.setNextAttributionSource])
     * attributes the microphone use to the calling app as well.
     *
     * @param onLevel Optional observer of the raw microphone level: called on the capture
     *   thread with the normalised RMS in [0.0, 1.0] of every chunk read from the hardware,
     *   before VAD filtering (so it also reports silence).
     * @param onSpeechProbability Optional observer of the VAD's raw per-frame speech
     *   probability ([VadFilter.lastSpeechProbability]), called on the capture thread for
     *   every chunk read while capturing (not for the drain after [stopCapture]); feeds a
     *   [SpeechEndpointer]. Only called with [vadEnabled].
     * @throws SecurityException if [android.Manifest.permission.RECORD_AUDIO] is not granted.
     * @throws IllegalStateException if [AudioRecord] fails to initialise.
     * @throws MicrophoneBusyException if another app has the microphone: recording does not
     *   start, or Android silences it (it then delivers only zeros) — at the start or later,
     *   e.g. when a phone call comes in.
     */
    // Permission is checked manually via PermissionHelper before AudioRecord is created.
    @SuppressLint("MissingPermission")
    fun startCapture(
        vadEnabled: Boolean = true,
        rawSource: Boolean = false,
        onLevel: ((Float) -> Unit)? = null,
        onSpeechProbability: ((Float) -> Unit)? = null,
    ): Flow<AudioChunk> =
        channelFlow {
            if (!PermissionHelper.hasRecordPermission(context)) {
                throw SecurityException(
                    "RECORD_AUDIO permission is not granted. " +
                            "Open the Parakeetype app to grant microphone access."
                )
            }

            stopRequested = false   // reset for this capture session

            // Only create a filter when VAD is enabled; null means pass-through (VAD disabled).
            val vad: VadFilter? = if (vadEnabled) {
                VadFilter.load(context)
            } else null.also { Log.d(TAG, "VAD disabled") }

            val minBufferBytes = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            // Use at least 2× the chunk size so the hardware buffer never overflows.
            val bufferBytes = maxOf(minBufferBytes, CHUNK_SAMPLES * 2 * 2)

            val source = if (rawSource) MediaRecorder.AudioSource.UNPROCESSED
            else MediaRecorder.AudioSource.DEFAULT

            val recorder = try {
                AudioRecord.Builder()
                    .setContext(context)
                    .setAudioSource(source)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferBytes)
                    .build()
            } catch (e: UnsupportedOperationException) {
                // Builder.build() reports an initialisation failure this way; callers handle
                // IllegalStateException (see the check below).
                throw IllegalStateException("AudioRecord failed to initialise: ${e.message}", e)
            }

            check(recorder.state == AudioRecord.STATE_INITIALIZED) {
                "AudioRecord failed to initialise (state=${recorder.state})"
            }

            // Apply the calibration-selected microphone (no-op when unset or the device is gone).
            applyPreferredMic(recorder)

            val buffer = ShortArray(CHUNK_SAMPLES)

            try {
                recorder.startRecording()
                if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    throw MicrophoneBusyException("AudioRecord did not start recording")
                }
                Log.d(TAG, "AudioRecord started - chunk=$CHUNK_SAMPLES samples, buf=$bufferBytes bytes")

                var chunksRead = 0
                while (currentCoroutineContext().isActive && !stopRequested) {
                    // Android does not fail a recording while another app holds the
                    // microphone (concurrent capture, API 29+): it keeps delivering silence.
                    if (chunksRead++ % SILENCED_CHECK_INTERVAL_CHUNKS == 0 &&
                        recorder.activeRecordingConfiguration?.isClientSilenced == true
                    ) {
                        throw MicrophoneBusyException("Recording is silenced - another app uses the microphone")
                    }
                    val read = recorder.read(buffer, 0, buffer.size)
                    when {
                        read > 0 -> {
                            val samples = buffer.copyOf(read)
                            val chunk = AudioChunk(samples = samples)
                            val rms = calculateRms(chunk.samples)
                            onLevel?.invoke(rms)

                            val toSend = vad?.process(chunk, rms) ?: listOf(chunk)
                            if (vad != null) onSpeechProbability?.invoke(vad.lastSpeechProbability)
                            for (c in toSend) {
                                send(c)
                            }
                        }

                        read == AudioRecord.ERROR_DEAD_OBJECT -> {
                            // Hardware-level error - the audio subsystem was taken away.
                            Log.e(TAG, "AudioRecord ERROR_DEAD_OBJECT - stopping capture")
                            return@channelFlow
                        }

                        read < 0 -> {
                            // Non-fatal read error - log and skip this chunk.
                            Log.w(TAG, "AudioRecord read returned error code: $read")
                        }
                        // read == 0: no data yet; continue the loop
                    }
                }

                // --> Trailing Audio Drain
                // When the user releases the record key, two sources of audio are still pending:
                //   1. Samples sitting in the AudioRecord hardware ring buffer not yet read.
                //   2. The VAD hangover window (up to 450 ms) that has not yet expired.
                // Draining both ensures the last word is never cut off mid-phoneme.

                if (stopRequested && currentCoroutineContext().isActive) {
                    // Phase 1: drain any remaining hardware buffer data (non-blocking reads).
                    var drained: Int
                    do {
                        drained = recorder.read(buffer, 0, buffer.size, AudioRecord.READ_NON_BLOCKING)
                        if (drained > 0) {
                            val chunk = AudioChunk(samples = buffer.copyOf(drained))
                            val rms = calculateRms(chunk.samples)
                            val toSend = vad?.process(chunk, rms) ?: listOf(chunk)
                            for (c in toSend) {
                                send(c)
                            }
                        }
                    } while (drained > 0)
                    Log.d(TAG, "AudioRecord hardware buffer drained")

                    // Phase 2: if VAD is still in hangover/speech, feed silence frames until
                    // the hangover counter expires and VAD transitions back to SILENCE.
                    // This guarantees the hangover tail is emitted before the flow completes.
                    if (vad != null) {
                        for (c in vad.drainHangover(CHUNK_SAMPLES)) {
                            send(c)
                        }
                    }
                }

            } finally {
                vad?.flush()
                vad?.close()
                recorder.stop()
                recorder.release()
                Log.d(TAG, "AudioRecord stopped and released")
            }
        }.flowOn(Dispatchers.IO)

    /**
     * Applies the calibration-selected microphone to [recorder] via `setPreferredDevice`
     * (API 29+). No-op when no calibration has run ([preferredMicId] == 0), the API is too
     * old, or the persisted device is no longer present (e.g. after a reboot or cable change).
     */
    private suspend fun applyPreferredMic(recorder: AudioRecord) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val id = prefs.preferredMicId.first()
        if (id == 0) return
        val device = MicCalibrationManager(context).deviceForId(id) ?: run {
            Log.w(TAG, "Preferred mic id=$id not present — using system default")
            return
        }
        try {
            recorder.setPreferredDevice(device)
            Log.d(TAG, "Applied preferred mic id=$id")
        } catch (e: Exception) {
            Log.w(TAG, "setPreferredDevice failed for id=$id", e)
        }
    }
}

/**
 * Computes the RMS amplitude of [samples] and normalises it to [0.0, 1.0] relative to
 * [Short.MAX_VALUE] (32 767).
 */
internal fun calculateRms(samples: ShortArray): Float {
    if (samples.isEmpty()) return 0f
    val sumOfSquares = samples.fold(0.0) { acc, s -> acc + s.toDouble() * s.toDouble() }
    val rms = sqrt(sumOfSquares / samples.size)
    return (rms / Short.MAX_VALUE.toDouble()).toFloat().coerceIn(0f, 1f)
}
