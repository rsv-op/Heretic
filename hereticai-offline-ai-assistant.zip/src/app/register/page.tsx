import Link from "next/link";
import { RegisterView } from "./RegisterView";

export const dynamic = "force-dynamic";

export default function RegisterPage() {
  return (
    <div>
      <RegisterView />
      <noscript>
        <Link href="/login">Sign in instead</Link>
      </noscript>
    </div>
  );
}
