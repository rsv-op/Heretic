import { ensureDemoSeed } from "@/lib/seed";
import { LoginView } from "./LoginView";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  try {
    await ensureDemoSeed();
  } catch {
    /* database not ready yet — the form still renders */
  }
  return <LoginView />;
}
