import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser, publicUser } from "@/lib/auth";
import { ensureDemoSeed } from "@/lib/seed";
import { Shell } from "@/components/Shell";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  try {
    await ensureDemoSeed();
  } catch {
    /* first request may race the database bootstrap; pages handle empty data */
  }

  const user = await getCurrentUser();
  if (!user) redirect("/login");

  return <Shell user={publicUser(user)}>{children}</Shell>;
}
