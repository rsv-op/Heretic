import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Heretic.ai — Offline Android Command Center",
  description:
    "Heretic.ai is an offline, on-device Alfred/Jarvis copilot: voice pipeline, error identification loop, file relevance assessor, repository tracker, authorization gates and a decision transparency log — bundled into a single Android APK.",
  applicationName: "Heretic.ai",
};

export const viewport: Viewport = {
  themeColor: "#06070a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-void text-chalk antialiased">
        <div aria-hidden className="pointer-events-none fixed inset-0 z-0">
          <div className="absolute inset-0 grid-etch opacity-[0.55]" />
          <div
            className="absolute -top-40 -left-32 h-[46rem] w-[46rem] rounded-full opacity-45 blur-[130px] animate-drift"
            style={{
              background:
                "radial-gradient(circle at 40% 40%, rgba(255,122,24,0.34), rgba(255,122,24,0) 62%)",
            }}
          />
          <div
            className="absolute top-1/3 -right-40 h-[38rem] w-[38rem] rounded-full opacity-35 blur-[140px] animate-drift"
            style={{
              animationDelay: "-9s",
              background:
                "radial-gradient(circle at 50% 50%, rgba(47,224,160,0.22), rgba(47,224,160,0) 64%)",
            }}
          />
          <div className="absolute inset-0 noise-layer opacity-[0.045] mix-blend-overlay" />
        </div>
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  );
}
