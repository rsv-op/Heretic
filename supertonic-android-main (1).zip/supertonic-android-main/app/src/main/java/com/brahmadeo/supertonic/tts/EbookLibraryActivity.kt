package com.brahmadeo.supertonic.tts

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.setValue
import com.brahmadeo.supertonic.tts.ui.theme.SupertonicTheme
import com.brahmadeo.supertonic.tts.utils.EbookManager
import com.brahmadeo.supertonic.tts.utils.RecentBook

class EbookLibraryActivity : ComponentActivity() {

    private val ebookOutlineLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            setResult(RESULT_OK, result.data)
            finish()
        }
    }

    private val ebookPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val localPath = EbookManager.importBook(this, it)
            if (localPath != null) {
                openBook(localPath)
            } else {
                Toast.makeText(this, "Failed to import book", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val recentBooksState = mutableStateOf<List<RecentBook>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            SupertonicTheme {
                LibraryScreen(
                    recentBooks = recentBooksState.value,
                    onBack = { finish() },
                    onOpenNew = { ebookPickerLauncher.launch(arrayOf("application/epub+zip", "application/pdf")) },
                    onBookClick = { openBook(it.path) },
                    onDeleteBook = { book ->
                        EbookManager.removeBook(this, book.path)
                        recentBooksState.value = EbookManager.getRecentBooks(this)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        recentBooksState.value = EbookManager.getRecentBooks(this)
    }

    private fun openBook(path: String) {
        val intent = Intent(this, EbookOutlineActivity::class.java).apply {
            putExtra(EbookOutlineActivity.EXTRA_URI, path)
        }
        ebookOutlineLauncher.launch(intent)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun LibraryScreen(
        recentBooks: List<RecentBook>,
        onBack: () -> Unit,
        onOpenNew: () -> Unit,
        onBookClick: (RecentBook) -> Unit,
        onDeleteBook: (RecentBook) -> Unit
    ) {
        var bookToDelete by remember { mutableStateOf<RecentBook?>(null) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Ebook Library") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = onOpenNew) {
                    Icon(Icons.Default.Add, contentDescription = "Open New Ebook")
                }
            }
        ) { paddingValues ->
            if (recentBooks.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No recent books", style = MaterialTheme.typography.bodyLarge)
                        Button(onClick = onOpenNew, modifier = Modifier.padding(top = 16.dp)) {
                            Text("Open your first book")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(paddingValues),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(recentBooks) { book ->
                        ListItem(
                            headlineContent = { Text(book.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(book.path, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingContent = { Icon(Icons.Default.Book, contentDescription = null) },
                            trailingContent = {
                                IconButton(onClick = { bookToDelete = book }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete book",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            modifier = Modifier.clickable { onBookClick(book) }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        if (bookToDelete != null) {
            AlertDialog(
                onDismissRequest = { bookToDelete = null },
                title = { Text("Delete Book") },
                text = { Text("Are you sure you want to remove \"${bookToDelete?.title}\" from the list?") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            bookToDelete?.let { onDeleteBook(it) }
                            bookToDelete = null
                        }
                    ) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { bookToDelete = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
